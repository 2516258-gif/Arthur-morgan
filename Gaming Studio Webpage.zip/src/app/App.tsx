import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { FeaturedGames } from './components/FeaturedGames';
import { About } from './components/About';
import { Team } from './components/Team';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <Hero />
      <FeaturedGames />
      <About />
      <Team />
      <Contact />
      <Footer />
    </div>
  );
}
