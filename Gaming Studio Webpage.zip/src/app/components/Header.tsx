import { Gamepad2, Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-md border-b border-purple-900/30">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => scrollToSection('hero')}>
            <Gamepad2 className="w-8 h-8 text-purple-500" />
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
              PixelForge
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollToSection('games')} className="text-gray-300 hover:text-purple-500 transition-colors">
              Games
            </button>
            <button onClick={() => scrollToSection('about')} className="text-gray-300 hover:text-purple-500 transition-colors">
              About
            </button>
            <button onClick={() => scrollToSection('team')} className="text-gray-300 hover:text-purple-500 transition-colors">
              Team
            </button>
            <button onClick={() => scrollToSection('contact')} className="text-gray-300 hover:text-purple-500 transition-colors">
              Contact
            </button>
            <button className="bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-2 rounded-full hover:from-purple-700 hover:to-pink-700 transition-all">
              Join Us
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 flex flex-col gap-4">
            <button onClick={() => scrollToSection('games')} className="text-gray-300 hover:text-purple-500 transition-colors text-left">
              Games
            </button>
            <button onClick={() => scrollToSection('about')} className="text-gray-300 hover:text-purple-500 transition-colors text-left">
              About
            </button>
            <button onClick={() => scrollToSection('team')} className="text-gray-300 hover:text-purple-500 transition-colors text-left">
              Team
            </button>
            <button onClick={() => scrollToSection('contact')} className="text-gray-300 hover:text-purple-500 transition-colors text-left">
              Contact
            </button>
            <button className="bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-2 rounded-full hover:from-purple-700 hover:to-pink-700 transition-all text-left">
              Join Us
            </button>
          </div>
        )}
      </nav>
    </header>
  );
}
