import { ImageWithFallback } from './figma/ImageWithFallback';
import { Target, Lightbulb, Heart, Award } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image Side */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1744339699989-550c61f3ecb8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lJTIwZGV2ZWxvcG1lbnQlMjBvZmZpY2V8ZW58MXx8fHwxNzcxOTI3NzA5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Game Development Office"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent"></div>
            </div>
            
            {/* Floating Stats */}
            <div className="absolute -bottom-6 -right-6 bg-gradient-to-br from-purple-600 to-pink-600 p-6 rounded-2xl shadow-2xl">
              <div className="text-4xl font-bold text-white mb-1">15+</div>
              <div className="text-purple-100">Years Experience</div>
            </div>
          </div>

          {/* Content Side */}
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
              About PixelForge Studios
            </h2>
            <p className="text-gray-300 text-lg mb-6">
              Founded in 2010, PixelForge Studios has been at the forefront of gaming innovation, 
              creating unforgettable experiences that resonate with players around the globe.
            </p>
            <p className="text-gray-400 mb-8">
              Our passionate team of developers, artists, and designers work tirelessly to push 
              the boundaries of interactive entertainment. We believe in crafting games that not 
              only entertain but also inspire and bring people together.
            </p>

            {/* Values Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-purple-600/20 rounded-lg flex items-center justify-center">
                  <Target className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-1">Our Mission</h3>
                  <p className="text-gray-400 text-sm">Create groundbreaking games that redefine entertainment</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-pink-600/20 rounded-lg flex items-center justify-center">
                  <Lightbulb className="w-6 h-6 text-pink-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-1">Innovation</h3>
                  <p className="text-gray-400 text-sm">Constantly pushing creative and technical boundaries</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-purple-600/20 rounded-lg flex items-center justify-center">
                  <Heart className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-1">Community</h3>
                  <p className="text-gray-400 text-sm">Building lasting connections with our players</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-pink-600/20 rounded-lg flex items-center justify-center">
                  <Award className="w-6 h-6 text-pink-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-1">Excellence</h3>
                  <p className="text-gray-400 text-sm">Delivering quality in every aspect of our work</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
