import { ImageWithFallback } from './figma/ImageWithFallback';
import { Twitter, Linkedin, Github } from 'lucide-react';

const teamMembers = [
  {
    id: 1,
    name: "Alex Chen",
    role: "CEO & Game Director",
    image: "https://images.unsplash.com/photo-1767455471543-055dbc6c6700?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdGVhbSUyMGdhbWluZ3xlbnwxfHx8fDE3NzE5Mjc3MDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    bio: "15+ years creating award-winning gaming experiences"
  },
  {
    id: 2,
    name: "Sarah Martinez",
    role: "Lead Designer",
    image: "https://images.unsplash.com/photo-1767455471543-055dbc6c6700?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdGVhbSUyMGdhbWluZ3xlbnwxfHx8fDE3NzE5Mjc3MDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    bio: "Passionate about crafting immersive player experiences"
  },
  {
    id: 3,
    name: "Marcus Johnson",
    role: "Technical Director",
    image: "https://images.unsplash.com/photo-1767455471543-055dbc6c6700?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdGVhbSUyMGdhbWluZ3xlbnwxfHx8fDE3NzE5Mjc3MDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    bio: "Engineering cutting-edge game technologies"
  },
  {
    id: 4,
    name: "Emily Zhang",
    role: "Art Director",
    image: "https://images.unsplash.com/photo-1767455471543-055dbc6c6700?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdGVhbSUyMGdhbWluZ3xlbnwxfHx8fDE3NzE5Mjc3MDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    bio: "Bringing stunning visual worlds to life"
  }
];

export function Team() {
  return (
    <section id="team" className="py-20 bg-gradient-to-b from-purple-950/20 to-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
            Meet Our Team
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            The talented individuals behind the magic of PixelForge Studios
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member) => (
            <div 
              key={member.id}
              className="group bg-gradient-to-b from-purple-900/20 to-black border border-purple-500/30 rounded-2xl overflow-hidden hover:border-purple-500 transition-all duration-300"
            >
              <div className="relative overflow-hidden h-72">
                <ImageWithFallback
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60"></div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-1">{member.name}</h3>
                <p className="text-purple-400 text-sm mb-3">{member.role}</p>
                <p className="text-gray-400 text-sm mb-4">{member.bio}</p>
                
                {/* Social Links */}
                <div className="flex gap-3">
                  <button className="w-8 h-8 rounded-full bg-purple-600/20 hover:bg-purple-600/40 flex items-center justify-center transition-colors">
                    <Twitter className="w-4 h-4 text-purple-400" />
                  </button>
                  <button className="w-8 h-8 rounded-full bg-purple-600/20 hover:bg-purple-600/40 flex items-center justify-center transition-colors">
                    <Linkedin className="w-4 h-4 text-purple-400" />
                  </button>
                  <button className="w-8 h-8 rounded-full bg-purple-600/20 hover:bg-purple-600/40 flex items-center justify-center transition-colors">
                    <Github className="w-4 h-4 text-purple-400" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
