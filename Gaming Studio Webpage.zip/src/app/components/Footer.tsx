import { Gamepad2, Twitter, Facebook, Instagram, Youtube, Twitch } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-black border-t border-purple-900/30 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <Gamepad2 className="w-8 h-8 text-purple-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
                PixelForge
              </span>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              Creating unforgettable gaming experiences since 2010.
            </p>
            <div className="flex gap-3">
              <button className="w-9 h-9 rounded-full bg-purple-600/20 hover:bg-purple-600/40 flex items-center justify-center transition-colors">
                <Twitter className="w-4 h-4 text-purple-400" />
              </button>
              <button className="w-9 h-9 rounded-full bg-purple-600/20 hover:bg-purple-600/40 flex items-center justify-center transition-colors">
                <Facebook className="w-4 h-4 text-purple-400" />
              </button>
              <button className="w-9 h-9 rounded-full bg-purple-600/20 hover:bg-purple-600/40 flex items-center justify-center transition-colors">
                <Instagram className="w-4 h-4 text-purple-400" />
              </button>
              <button className="w-9 h-9 rounded-full bg-purple-600/20 hover:bg-purple-600/40 flex items-center justify-center transition-colors">
                <Youtube className="w-4 h-4 text-purple-400" />
              </button>
              <button className="w-9 h-9 rounded-full bg-purple-600/20 hover:bg-purple-600/40 flex items-center justify-center transition-colors">
                <Twitch className="w-4 h-4 text-purple-400" />
              </button>
            </div>
          </div>

          {/* Games */}
          <div>
            <h4 className="text-white font-semibold mb-4">Games</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Neon Warriors</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Mystic Realms</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Velocity Racers</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">All Games</a></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white font-semibold mb-4">Company</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">About Us</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Careers</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Press Kit</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Blog</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-white font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Help Center</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Community</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Contact Us</a></li>
              <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Privacy Policy</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-purple-900/30 pt-8 text-center">
          <p className="text-gray-500 text-sm">
            © 2026 PixelForge Studios. All rights reserved. | Made with ❤️ for gamers worldwide
          </p>
        </div>
      </div>
    </footer>
  );
}
