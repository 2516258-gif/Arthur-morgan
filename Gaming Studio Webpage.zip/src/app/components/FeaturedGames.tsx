import { ImageWithFallback } from './figma/ImageWithFallback';
import { Gamepad2, Calendar, TrendingUp } from 'lucide-react';

const games = [
  {
    id: 1,
    title: "Neon Warriors",
    genre: "Action RPG",
    image: "https://images.unsplash.com/photo-1610561212775-b191f21b6998?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWRlbyUyMGdhbWUlMjBjb250cm9sbGVyJTIwbmVvbnxlbnwxfHx8fDE3NzE4MzMyOTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    status: "Coming Soon",
    releaseDate: "Q3 2026",
    description: "An electrifying cyberpunk adventure set in a dystopian future"
  },
  {
    id: 2,
    title: "Mystic Realms",
    genre: "Fantasy MMORPG",
    image: "https://images.unsplash.com/photo-1765606290905-b9d377ea4d5e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwZ2FtZSUyMGFydHxlbnwxfHx8fDE3NzE4NDA0MTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    status: "Live Now",
    releaseDate: "Available",
    description: "Explore vast magical worlds filled with epic quests and mythical creatures"
  },
  {
    id: 3,
    title: "Velocity Racers",
    genre: "Racing",
    image: "https://images.unsplash.com/photo-1717995045693-51ca3745213b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBnYW1lJTIwc2NyZWVuc2hvdHxlbnwxfHx8fDE3NzE5MjUxOTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    status: "Trending",
    releaseDate: "Available",
    description: "High-octane racing action with stunning graphics and intense competition"
  }
];

export function FeaturedGames() {
  return (
    <section id="games" className="py-20 bg-gradient-to-b from-black to-purple-950/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
            Featured Games
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Discover our latest titles that have captivated millions of players worldwide
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {games.map((game) => (
            <div 
              key={game.id} 
              className="group bg-gradient-to-b from-purple-900/20 to-black border border-purple-500/30 rounded-2xl overflow-hidden hover:border-purple-500 transition-all duration-300 hover:transform hover:scale-105"
            >
              <div className="relative overflow-hidden h-64">
                <ImageWithFallback
                  src={game.image}
                  alt={game.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 right-4">
                  <span className={`px-4 py-1 rounded-full text-sm font-semibold ${
                    game.status === 'Live Now' ? 'bg-green-500' : 
                    game.status === 'Trending' ? 'bg-orange-500' : 
                    'bg-purple-500'
                  }`}>
                    {game.status}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center gap-2 text-purple-400 mb-2">
                  <Gamepad2 className="w-4 h-4" />
                  <span className="text-sm">{game.genre}</span>
                </div>
                
                <h3 className="text-2xl font-bold text-white mb-2">{game.title}</h3>
                <p className="text-gray-400 mb-4">{game.description}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-gray-500">
                    <Calendar className="w-4 h-4" />
                    <span className="text-sm">{game.releaseDate}</span>
                  </div>
                  <button className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg transition-colors">
                    Learn More
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
