import { Play, Star, Users } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Hero() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1733945761533-727f49908d70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cCUyMGNvbXB1dGVyfGVufDF8fHx8MTc3MTg4NDg5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Gaming Setup"
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-purple-900/20 to-black"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-purple-400 via-pink-500 to-purple-600 bg-clip-text text-transparent">
            Welcome to PixelForge Studios
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8">
            Creating immersive gaming experiences that push the boundaries of imagination
          </p>
          
          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-8 mb-12">
            <div className="flex items-center gap-2">
              <Star className="w-6 h-6 text-yellow-500" />
              <div className="text-left">
                <div className="text-2xl font-bold text-white">50+</div>
                <div className="text-sm text-gray-400">Awards Won</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-6 h-6 text-purple-500" />
              <div className="text-left">
                <div className="text-2xl font-bold text-white">10M+</div>
                <div className="text-sm text-gray-400">Active Players</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Play className="w-6 h-6 text-pink-500" />
              <div className="text-left">
                <div className="text-2xl font-bold text-white">25+</div>
                <div className="text-sm text-gray-400">Games Released</div>
              </div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-wrap justify-center gap-4">
            <button className="bg-gradient-to-r from-purple-600 to-pink-600 px-8 py-4 rounded-full text-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all transform hover:scale-105">
              Explore Our Games
            </button>
            <button className="border-2 border-purple-500 px-8 py-4 rounded-full text-lg font-semibold hover:bg-purple-500/20 transition-all">
              Watch Trailer
            </button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-purple-500 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-purple-500 rounded-full mt-2"></div>
        </div>
      </div>
    </section>
  );
}
