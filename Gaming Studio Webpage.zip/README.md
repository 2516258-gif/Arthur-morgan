
  # Gaming Studio Webpage

  This is a code bundle for Gaming Studio Webpage. The original project is available at https://www.figma.com/design/fDbO87QnasRAF5VhQCE0xI/Gaming-Studio-Webpage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  